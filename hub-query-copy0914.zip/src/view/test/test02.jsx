import React,{Component} from 'react'
import { Select } from 'antd';
import propTypes from 'prop-types'

const Option = Select.Option;


class Test03 extends Component{
    state = {
        size: 'default',
        options:[
            {value: "4332978f-765d-47f2-ba5e-27cd1f3c95e5", label: "gade"},
            {value: "3c06ae12-aa8b-420c-a023-f4032a77af08", label: "ledf"},
            {value: "f765d50b-c996-4ff9-ab95-5c12db86f9e2", label: "gayrt"},
            {value: "3c06ae12-aa8b-420c-a023-f4032a7fwegfweg", label: "legthf"},
            {value: "f765d50b-c996-4ff9-ab95-5c12dbwgewgwwqeq21", label: "hhtr"},
            {value: "3c06ae12-aa8b-420c-a023-ffweff08", label: "frh"},
            {value: "f765d50b-c996-4ff9-ab95-r32235", label: "yyer"},
            {value: "3c06ae12-aa8b-420c-a023-31455", label: "yry"},
            {value: "f765d50b-c996-4ff9-ab95-663473", label: "jjyi"}
        ]
    };
    static propTypes={
        states:propTypes.array.isRequired
    }
    handleChange=(value)=> {
        console.log(`selected ${value}`);
    }
    
    handleBlur=()=> {
        console.log('blur');
    }
    
    handleFocus=()=> {
        console.log('focus');
    }
    render(){
        return(
            <div>
                <Select
                    showSearch
                    size={this.state.size}
                    allowClear={true}
                    style={{ width: 200 }}
                    placeholder="Select a person"
                    optionFilterProp="children"
                    onChange={this.handleChange}
                    onFocus={this.handleFocus}
                    onBlur={this.handleBlur}
                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                >
                    {
                        this.props.states.map((item,idx)=> {
                            return (
                                <Option key={idx} value={item.value}>{item.label}</Option>
                            )
                        })
                    }
                </Select>
            </div>
        )
    }
}
export default Test03
