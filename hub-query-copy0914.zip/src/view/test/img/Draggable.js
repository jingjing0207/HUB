// export {DraggableArea, DraggableAreasGroup} from '../src';
export {DraggableArea, DraggableAreasGroup} from 'react-draggable-tags';