export default {
  leftTags: [{
    id: 'apple',
    name: 'apple',
  },{
    id: 'watermelon',
    name: 'watermelon',
  },{
    id: 'banana',
    name: 'banana',
  },{
    id: 'lemon',
    name: 'lemon',
  },{
    id: 'orange',
    name: 'orange',
  },{
    id: 'grape',
    name: 'grape',
  },{
    id: 'strawberry',
    name: 'strawberry',
  },{
    id: 'cherry',
    name: 'cherry',
  }],
  rightTags: [{
    id: 'tomato',
    name: 'tomato',
  },{
    id: 'cucumber',
    name: 'cucumber',
  },{
    id: 'mushroom',
    name: 'mushroom',
  },{
    id: 'pea',
    name: 'pea',
  },{
    id: 'carrot',
    name: 'carrot',
  },{
    id: 'cabbage',
    name: 'cabbage',
  },{
    id: 'Chinese cabbage',
    name: 'Chinese cabbage',
  },{
    id: 'melon',
    name: 'melon',
  },{
    id: 'celery',
    name: 'celery',
  },{
    id: 'pepper',
    name: 'pepper',
  },{
    id: 'eggplant',
    name: 'eggplant',
  },{
    id: 'beet',
    name: 'beet',
  },{
    id: 'been',
    name: 'been',
  }],
}