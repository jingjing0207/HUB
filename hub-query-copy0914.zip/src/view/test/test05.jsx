import React,{Component} from 'react'
import { List, message, Spin,Table } from 'antd';
import reqwest from 'reqwest';

import InfiniteScroll from 'react-infinite-scroller';
import './test.css'

const fakeDataUrl = 'http://192.168.88.168:8080/api/preview?id=61777';

class Test05 extends Component {
    state = {
        data: [],
        loading: false,
        hasMore: true,
        headerData:[],
        totle:0,
        columns:[]
    }
    
    getData = (callback) => {
        let token = "Bearer " + 'eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodWJfcXVlcnkiLCJzdWIiOiJ2aWV3IiwiYXVkIjoid2ViIiwiaWF0IjoxNTM2MjMwMTE1LCJleHAiOjE1MzYyMzM3MTV9.DV7OvVMpekQcFokfWkjceS9cv32CY-uYp1_CgL9YTG4'
        reqwest({
            url: fakeDataUrl,
            type: 'json',
            method: 'get',
            headers: {
                'Content-type': 'application/json;charset=UTF-8',
                'Authorization': token
            },
            contentType: 'application/json',
            success: (res) => {
                callback(res);
            },
        });
    }
    
    componentDidMount() {
        this.getData((res) => {
            console.log('getData',res)
            this.setState({
                data: res.body,
                columns:res.header,
                totle:res.totalSize
            });
        });
    }
    
    handleInfiniteOnLoad = () => {
        let data = this.state.data;
        this.setState({
            loading: true,
        });
        if (data.length > this.state.data.length) {
            message.warning('Infinite List loaded all');
            this.setState({
                hasMore: false,
                loading: false,
            });
            return;
        }
        this.getData((res) => {
            data = data.concat( res.body);
            this.setState({
                data,
                loading: false,
            });
        });
    }
    render() {
        return (
            <div className="demo-infinite-container">
                <InfiniteScroll
                    initialLoad={false}
                    pageStart={0}
                    loadMore={this.handleInfiniteOnLoad}
                    hasMore={!this.state.loading && this.state.hasMore}
                    useWindow={false}
                >
                    <Table dataSource={this.state.data} columns={this.state.columns} pagination={false}>
                        {
                            this.state.loading && this.state.hasMore && (
                                <div className="demo-loading-container">
                                    <Spin />
                                </div>
                            )
                        }
                    </Table>
                    
                    {/*<List*/}
                        {/*dataSource={this.state.data}*/}
                        {/*renderItem={(item,idx) => (*/}
                            {/*<List.Item key={idx}>*/}
                                {/*{*/}
                                    {/*item.map((item,idx)=>(*/}
                                        {/*<List.Item.Meta*/}
                                            {/*key={idx}*/}
                                            {/*description={item}*/}
                                        {/*/>*/}
                                    {/*))*/}
                                {/*}*/}
                            {/*</List.Item>*/}
                        {/*)}*/}
                    {/*>*/}
                        {/*{this.state.loading && this.state.hasMore && (*/}
                            {/*<div className="demo-loading-container">*/}
                                {/*<Spin />*/}
                            {/*</div>*/}
                        {/*)}*/}
                    {/*</List>*/}
                </InfiniteScroll>
            </div>
        );
    }
}

export default Test05
