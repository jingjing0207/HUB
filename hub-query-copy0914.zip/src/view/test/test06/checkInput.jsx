import React ,{Component} from 'react'
import { Form,Input,message} from 'antd'
const createForm = Form.create;
const FormItem = Form.Item;
function noop() {
    return false;
}
class Login extends Component {
    constructor(props) {
        super(props)
        this.state={
            horizontal:'true',
            phoneNumber:'',
            initPassword:'',
            initialremember:'checked'
        }
        this.handleReset=this.handleReset.bind(this)
        this.phoneNumberTest=this.phoneNumberTest.bind(this)
        this.alertmessage=this.alertmessage.bind(this)
    }
    handleReset(e) {
        e.preventDefault();
        this.props.form.resetFields();
    }
    alertmessage (type,message){
        message[type](message);
    }
    phoneNumberTest(rule, value, callback) {
        if (!value) {
            callback([new Error('登录账号不能为空！')])
        } else {
            setTimeout(() => {
                let reg = /^1[3|4|5|7|8][0-9]{9}$/
                if (!reg.test(value)) {
                    callback([new Error('手机号不合法')])
                } else {
                    callback()
                }
            }, 800);
        }
    }
    render() {
        const { getFieldError, isFieldValidating, getFieldDecorator} = this.props.form;
        const formItemLayout = {
            labelCol: {span: 7},
            wrapperCol: {span: 12},
        };
        return (
            <Form horizontal={this.state.horizontal} form={this.props.form}>
                <FormItem
                    {...formItemLayout}
                    hasFeedback
                    wrapperCol={{span: 20, offset: 2}}
                    help={isFieldValidating('phoneNumber') ? '校验中...' : (getFieldError('phoneNumber') || []).join(', ')}
                >
                    {
                        getFieldDecorator('phoneNumber',{
                            initialValue:this.state.phoneNumber,
                            rules: [
                                {validator: this.phoneNumberTest},
                            ]
                        })(
                            <Input
                                style={{width: '100%'}} placeholder="请输入手机号"/>
                        )
                    }
                </FormItem>
            </Form>
        )
        
    }
}
export default (createForm()(Login))
