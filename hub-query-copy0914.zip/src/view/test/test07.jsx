import React,{Component} from 'react'
import { DatePicker } from 'antd';
import moment from 'moment';

const { RangePicker } = DatePicker;

class Test07 extends Component{
    state = {
        startValue: null,
        endValue: null,
        endOpen: false,
        startTime:'',
        endTime:''
    };
    
    disabledStartDate = (startValue) => {
        // console.log('==startValue==>',startValue)
        const endValue = this.state.endValue;
        if (!startValue || !endValue) {
            return false;
        }
        // console.log('==startValue==>',startValue.valueOf())
        return startValue.valueOf() > endValue.valueOf();
    }
    
    disabledEndDate = (endValue) => {
        // console.log('==endValue==>',endValue)
        const startValue = this.state.startValue;
        if (!endValue || !startValue) {
            return false;
        }
        console.log((this.state.endTime)-(this.state.startTime))
        // console.log('==endValue==>',endValue.valueOf())
        return this.state. startTime-this.state.endTime===-1209600000 <= endValue.valueOf() <= startValue.valueOf();
    }
    
    onChange = (field, value) => {
        this.setState({
            [field]: value,
        });
    }
    
    onStartChange = (value) => {
        this.onChange('startValue', value);
    }
    
    onEndChange = (value) => {
        this.onChange('endValue', value);
    }
    
    handleStartOpenChange = (open) => {
        if (!open) {
            this.setState({ endOpen: true });
        }
    }
    
    handleEndOpenChange = (open) => {
        this.setState({ endOpen: open });
    }
    dateToMs= (date) =>{
        let result = new Date(date).getTime();
        return result;
    }
    selectStartTime=(value) =>{
        this.setState({
            startTime:this.dateToMs(value._d)
        })
        console.log('Selected start Time: ', this.dateToMs(value._d));
    }
    selectEndTime=(value) =>{
        this.setState({
            endTime:this.dateToMs(value._d)
        })
        console.log('Selected end Time: ',this.dateToMs(value._d));
    }
    filterOption=(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    render(){
        const { startValue, endValue, endOpen } = this.state;
        return (
            <div>
                <DatePicker
                    disabledDate={this.disabledStartDate}
                    showTime
                    format="YYYY-MM-DD HH:mm:ss"
                    value={startValue}
                    placeholder="Start"
                    onChange={this.onStartChange}
                    onOpenChange={this.handleStartOpenChange}
                    onOk={this.selectStartTime}
                />
                <DatePicker
                    disabledDate={this.disabledEndDate}
                    showTime
                    format="YYYY-MM-DD HH:mm:ss"
                    value={endValue}
                    placeholder="End"
                    onChange={this.onEndChange}
                    open={endOpen}
                    onOpenChange={this.handleEndOpenChange}
                    onOk={this.selectEndTime}
                />
            </div>
        );
    }
}
export default Test07
