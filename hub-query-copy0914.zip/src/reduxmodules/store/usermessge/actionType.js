


export const TOKEN='TOKEN'

// const actionsType={
//     // 保存登录状态数据
//     loginAttud:{
//         LOGIN:'isLogin',
//         LOGOUT:'isLogout',
//
//     },
//     // 保存主机名端口号数据
//     TOKEN:{
//         token:'token',
//
//     },
//     // 保存登录后的个人数据
//     USERMES:{
//         usermes:'user',
//
//     },
// }
// export  default actionsType
